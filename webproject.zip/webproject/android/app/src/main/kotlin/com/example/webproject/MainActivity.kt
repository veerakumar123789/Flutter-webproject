package com.example.webproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
